
# Boosting_2 - Boosting for Boost_plus-Function  .....................................................

# Output:
# W-Boost_pass - Updated weight vector

#Target_Boost2 = as.matrix(Target_Boost)
#W_Boost2 = as.matrix(W_Boost)
#t2 = 0.05
#d2 = 0.25
#up_rate = 1
#OUT_INCLUDE_OVERALL = as.matrix(OUT_INC_OVERALL_1)



Boosting_2 <- function(Target_Boost2, W_Boost2, t2, d2, up_rate, boost_j, SCORE_LIST_SET_NORM, OUT_INCLUDE_OVERALL)
{
  #up_rate = 1.75
  
  points_b = dim(W_Boost2)[1] # points_b are total no of points in data 
  outliers_included = matrix(data=0, nrow =points_b, ncol=1)
  temp_b = matrix(data=0, nrow =points_b, ncol=1)
  
  temp_b = as.matrix(SCORE_LIST_SET_NORM[,boost_j])
  outliers_included = Convert_binary(temp_b,t2) # top-t outliers of boost_j, the newly added member
  
  top_tc = floor(points_b*t2)

    difficult_ex = 0
    easy_ex = 0
    for(i in 1:points_b)
    {
      if((Target_Boost2[i,1]==1)&&(outliers_included[i,1]==1))
      { 
        W_Boost2[i,1] = W_Boost2[i,1]*d2
        #if(w_temp>)
        easy_ex = easy_ex+1
      }
    }
    
    difficult_ex = top_tc-easy_ex
    W_Boost_up_out = 1/(4*difficult_ex);
    W_Boost_up_out_easy = 1/(4*easy_ex);
    
    for(i in 1:points_b)
    {
      if((Target_Boost2[i,1]==1)&&(outliers_included[i,1]==1))
      { 
        #W_Boost2[i,1] = W_Boost_up_out_easy
        #OUT_INCLUDE_OVERALL[i,1] = 1
      }else if((Target_Boost2[i,1]==1)&&(outliers_included[i,1]==0)){ 
        if(OUT_INCLUDE_OVERALL[i,1]==0)
        {  # means not covered by anyone till this point
          #W_Boost2[i,1] = W_Boost_up_out
          
            W_Boost2[i,1] = W_Boost2[i,1]*up_rate
          
            w_temp = W_Boost2[i,1]*up_rate
            if(w_temp<=20) # 2 is upper weight threshold, to be set experimentally
            {
              #W_Boost2[i,1] = w_temp
            }
         }
      }
    }
  
  #W_Boost2_Lnorm = as.matrix(L_Norm(W_Boost2))  
    
  # normalizing weights .............................................
    
    W_Boost2_norm = matrix(data=0, nrow = points_b, ncol=1)
    w_sum = sum(W_Boost2[,1])
    for(i in 1:points_b)
    {
      W_Boost2_norm[i,1] = W_Boost2[i,1]/w_sum
    }
    
    
  W_BOOST_OUT_INC_OVERALL = matrix(data=0, nrow = points_b, ncol=2)
  W_BOOST_OUT_INC_OVERALL[,1] = W_Boost2_norm[,1] #W_Boost2[,1]
  W_BOOST_OUT_INC_OVERALL[,2] = OUT_INCLUDE_OVERALL[,1]
    
  return(W_BOOST_OUT_INC_OVERALL)
} # END OF THE FUNCTION ........................................................

